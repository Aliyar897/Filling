﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
namespace Filling
{
    public partial class Filling : Form
    {
        public Filling()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            DirectoryInfo dir = new DirectoryInfo(comboBox1.Text);
            DirectoryInfo[] d = dir.GetDirectories();
            foreach(DirectoryInfo df in d)
            {
                comboBox2.Items.Add(df);
            }
        }

        private void Filling_Load(object sender, EventArgs e)
        {
            this.MaximizeBox = false;
            comboBox1.Items.Add("C:\\");
            comboBox1.Items.Add("E:\\");
            comboBox3.Items.Add("C:\\");
            comboBox3.Items.Add("E:\\");

            comboBox19.Items.Add("C:\\");
            comboBox19.Items.Add("E:\\");

            comboBox15.Items.Add("C:\\");
            comboBox15.Items.Add("E:\\");

            comboBox13.Items.Add("C:\\");
            comboBox13.Items.Add("E:\\");
            comboBox11.Items.Add("C:\\");
            comboBox11.Items.Add("E:\\");

            comboBox5.Items.Add("C:\\");
            comboBox5.Items.Add("E:\\");
            comboBox7.Items.Add("C:\\");
            comboBox7.Items.Add("E:\\");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
            string fpath = comboBox1.Text + comboBox2.Text + "\\" + textBox1.Text;
            
            if (!File.Exists(fpath) && textBox1.Text!="" && comboBox1.Text!="" && comboBox2.Text!="")
            {
                
                    Directory.CreateDirectory(fpath);
                    MessageBox.Show("Folder Has Been Created!");
            }
                               
            else
            {
                MessageBox.Show("there is An Error Please Check");
            }
            }
            catch (FileNotFoundException ex) { MessageBox.Show(ex.Message); }
            catch (Exception ex) { MessageBox.Show(ex.Message); }

           
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string fpath = comboBox3.Text + comboBox4.Text + "\\" + textBox2.Text+".txt";
            try{
            if (!File.Exists(fpath))
            {
                
                    File.Create(fpath);
                    MessageBox.Show("File Has Been Created!");
               
            }
            else
            {
                MessageBox.Show("File Already exits");
            }
            }
            catch (FileNotFoundException ex) { MessageBox.Show(ex.Message); }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
           
        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            DirectoryInfo dir = new DirectoryInfo(comboBox3.Text);
            DirectoryInfo[] d = dir.GetDirectories();
            foreach (DirectoryInfo df in d)
            {
                comboBox4.Items.Add(df);
            }
        }

        private void comboBox5_SelectedIndexChanged(object sender, EventArgs e)
        {
            DirectoryInfo dir = new DirectoryInfo(comboBox5.Text);
            DirectoryInfo[] d = dir.GetDirectories();
            foreach (DirectoryInfo df in d)
            {
                comboBox6.Items.Add(df);
            }
        }

        private void comboBox6_SelectedIndexChanged(object sender, EventArgs e)
        {
            string fpath = comboBox5.Text +comboBox6.Text+"\\";
            FileInfo info = new FileInfo(fpath);
            FileInfo[] f = info.Directory.GetFiles();
            foreach(FileInfo inf in f)
            {
                comboBox9.Items.Add(inf);
            }
        }

        private void comboBox7_SelectedIndexChanged(object sender, EventArgs e)
        {
            DirectoryInfo dir = new DirectoryInfo(comboBox7.Text);
            DirectoryInfo[] d = dir.GetDirectories();
            foreach (DirectoryInfo df in d)
            {
                comboBox8.Items.Add(df);
            }
           
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //Could not find file 'E:\Ginansss.txt\'.
                string fspath = comboBox5.Text + comboBox6.Text +"\\"+ comboBox9.Text;
                string fpath = comboBox7.Text + comboBox8.Text + "\\" + textBox4.Text;
            try{
                if (!File.Exists(fpath))
                {
                    
                        File.Copy(fspath, fpath);
                        MessageBox.Show("File is copied");
                }
            else{
                MessageBox.Show("there is issue");
                }
            }
            catch (FileNotFoundException ex) { MessageBox.Show(ex.Message); }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
                    
                
        }

        private void comboBox13_SelectedIndexChanged(object sender, EventArgs e)
        {

            DirectoryInfo dir = new DirectoryInfo(comboBox13.Text);
            DirectoryInfo[] d = dir.GetDirectories();
            foreach (DirectoryInfo df in d)
            {
                comboBox14.Items.Add(df);
            }
        }

        private void comboBox14_SelectedIndexChanged(object sender, EventArgs e)
        {
            string fpath = comboBox13.Text + comboBox14.Text + "\\";
            FileInfo info = new FileInfo(fpath);
            FileInfo[] f = info.Directory.GetFiles();
            foreach (FileInfo inf in f)
            {
                comboBox10.Items.Add(inf);
            }
        }

        private void comboBox11_SelectedIndexChanged(object sender, EventArgs e)
        {
            DirectoryInfo dir = new DirectoryInfo(comboBox11.Text);
            DirectoryInfo[] d = dir.GetDirectories();
            foreach (DirectoryInfo df in d)
            {
                comboBox12.Items.Add(df);
            }
          
        }

        private void groupBox3_Enter(object sender, EventArgs e)
        {

        }

        private void comboBox8_SelectedIndexChanged(object sender, EventArgs e)
        {
            textBox4.Text = comboBox9.Text;
        }

        private void comboBox12_SelectedIndexChanged(object sender, EventArgs e)
        {
            textBox3.Text = comboBox10.Text;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string fspath = comboBox13.Text + comboBox14.Text + "\\" + comboBox10.Text;
            string fpath = comboBox11.Text + comboBox12.Text + "\\" + textBox3.Text;
            try{
            if (!File.Exists(fpath))
            {
               
                    File.Move(fspath, fpath);
                    MessageBox.Show("File hes been moved");
            }
            else
            {
                MessageBox.Show("there is an issue");
            }
            }
            catch (FileNotFoundException ex) { MessageBox.Show(ex.Message); }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
           
        }

        private void comboBox15_SelectedIndexChanged(object sender, EventArgs e)
        {

            DirectoryInfo dir = new DirectoryInfo(comboBox15.Text);
            DirectoryInfo[] d = dir.GetDirectories();
            foreach (DirectoryInfo df in d)
            {
                comboBox16.Items.Add(df);
            }
           
        }

        private void comboBox16_SelectedIndexChanged(object sender, EventArgs e)
        {
            string fpath = comboBox15.Text + comboBox16.Text + "\\";
            FileInfo info = new FileInfo(fpath);
            FileInfo[] f = info.Directory.GetFiles();
            foreach (FileInfo inf in f)
            {
                comboBox17.Items.Add(inf);
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            try
            {
                string fpath = comboBox15.Text + comboBox16.Text + "\\" + comboBox17.Text;
                if (File.Exists(fpath))
                {
                    File.Delete(fpath);
                    MessageBox.Show("File hes been Deleted");
                }
                else
                {
                    MessageBox.Show("something went wrong");
                }
            }
            catch (FileNotFoundException ex) { MessageBox.Show(ex.Message); }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void comboBox17_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBox19_SelectedIndexChanged(object sender, EventArgs e)
        {
            DirectoryInfo dir = new DirectoryInfo(comboBox19.Text);
            DirectoryInfo[] d = dir.GetDirectories();
            foreach (DirectoryInfo df in d)
            {
                comboBox20.Items.Add(df);
            }
        }

        private void comboBox20_SelectedIndexChanged(object sender, EventArgs e)
        {
            string fpath = comboBox19.Text + comboBox20.Text + "\\";
            FileInfo info = new FileInfo(fpath);
            FileInfo[] f = info.Directory.GetFiles();
           
            foreach (FileInfo inf in f)
            {
                comboBox18.Items.Add(inf);
            }
        }

        private void comboBox18_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }

        private void button6_Click(object sender, EventArgs e)
        {
            string fpath = comboBox19.Text + comboBox20.Text + "\\";
            if(!File.Exists(fpath))
            {
                
            }
        }

        private void comboBox14_Click(object sender, EventArgs e)
        {
            
        }
    }
}
