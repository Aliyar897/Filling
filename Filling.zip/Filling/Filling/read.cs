﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Filling
{
    public partial class read : Form
    {
        public read()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                string path = comboBox5.Text + comboBox6.Text + "\\" + comboBox9.Text;
                StreamReader sr = new StreamReader(path);
                textBox1.Text = sr.ReadToEnd();
                sr.Close();
            }
            catch (FileNotFoundException ex) { MessageBox.Show(ex.Message); }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
          
        }

        private void read_Load(object sender, EventArgs e)
        {
            comboBox5.Items.Add("C:\\");
            comboBox5.Items.Add("E:\\");
            comboBox2.Items.Add("C:\\");
            comboBox2.Items.Add("E:\\");
            comboBox7.Items.Add("C:\\");
            comboBox7.Items.Add("E:\\");
            comboBox11.Items.Add("C:\\");
            comboBox11.Items.Add("E:\\");

        }

        private void comboBox5_SelectedIndexChanged(object sender, EventArgs e)
        {
            DirectoryInfo dir = new DirectoryInfo(comboBox5.Text);
            DirectoryInfo[] d = dir.GetDirectories();
            foreach (DirectoryInfo df in d)
            {
                comboBox6.Items.Add(df);
            }
        }

        private void comboBox9_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBox6_SelectedIndexChanged(object sender, EventArgs e)
        {
            string fpath = comboBox5.Text + comboBox6.Text + "\\";
            FileInfo info = new FileInfo(fpath);
            FileInfo[] f = info.Directory.GetFiles();
            foreach (FileInfo inf in f)
            {
                comboBox9.Items.Add(inf);
            }
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

            DirectoryInfo dir = new DirectoryInfo(comboBox2.Text);
            DirectoryInfo[] d = dir.GetDirectories();
            foreach (DirectoryInfo df in d)
            {
                comboBox3.Items.Add(df);
            }
        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            string fpath = comboBox2.Text + comboBox3.Text + "\\";
            FileInfo info = new FileInfo(fpath);
            FileInfo[] f = info.Directory.GetFiles();
            foreach (FileInfo inf in f)
            {
                comboBox1.Items.Add(inf);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string path = comboBox2.Text + comboBox3.Text + "\\" + comboBox1.Text;
                StreamWriter sr = new StreamWriter(path, append: true);
                sr.Write(textBox2.Text, true);
                sr.Close();
                MessageBox.Show("done!");
            }
            catch (FileNotFoundException ex) { MessageBox.Show(ex.Message); }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void comboBox7_SelectedIndexChanged(object sender, EventArgs e)
        {

            DirectoryInfo dir = new DirectoryInfo(comboBox7.Text);
            DirectoryInfo[] d = dir.GetDirectories();
            foreach (DirectoryInfo df in d)
            {
                comboBox8.Items.Add(df);
            }
        }

        private void comboBox8_SelectedIndexChanged(object sender, EventArgs e)
        {
            string fpath = comboBox7.Text + comboBox8.Text + "\\";
            FileInfo info = new FileInfo(fpath);
            FileInfo[] f = info.Directory.GetFiles();
            foreach (FileInfo inf in f)
            {
                comboBox4.Items.Add(inf);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                byte[] ba = new byte[100];
                char[] ca = new char[100];
                string fpath = comboBox7.Text + comboBox8.Text + "\\" + comboBox4.Text;
                FileStream fs = new FileStream(fpath, FileMode.OpenOrCreate);
                fs.Seek(6, SeekOrigin.Begin);
                fs.Read(ba, 0, 99);
                Decoder dc = Encoding.UTF8.GetDecoder();
                dc.GetChars(ba, 0, ba.Length, ca, 0);
                string s = new string(ca);
                textBox3.Text = s;
                fs.Close();
            }
            catch (FileNotFoundException ex) { MessageBox.Show(ex.Message); }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
          
           
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Button b = new Button();
            this.Controls.Add(b);
            b.Text = "buy it..";
            b.Location = new Point(583,330);
        }

        private void comboBox11_SelectedIndexChanged(object sender, EventArgs e)
        {

            DirectoryInfo dir = new DirectoryInfo(comboBox11.Text);
            DirectoryInfo[] d = dir.GetDirectories();
            foreach (DirectoryInfo df in d)
            {
                comboBox12.Items.Add(df);
            }
        }

        private void comboBox12_SelectedIndexChanged(object sender, EventArgs e)
        {
            string fpath = comboBox11.Text + comboBox12.Text + "\\";
            FileInfo info = new FileInfo(fpath);
            FileInfo[] f = info.Directory.GetFiles();
            foreach (FileInfo inf in f)
            {
                comboBox10.Items.Add(inf);
            }
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            try
            {
                byte[] ba = new byte[100];
                char[] ca = new char[100];
                string fpath = comboBox11.Text + comboBox12.Text + "\\" + comboBox10.Text;
                FileStream fs = new FileStream(fpath, FileMode.Append, FileAccess.Write);
                ca = textBox4.Text.ToCharArray();
                Encoder en = Encoding.UTF8.GetEncoder();
                en.GetBytes(ca, 0, ca.Length, ba, 0, true);
                fs.Write(ba, 0, ba.Length);
                fs.Close();
                MessageBox.Show("done");
            }
            catch (FileNotFoundException ex) { MessageBox.Show(ex.Message); }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }
    }
}
